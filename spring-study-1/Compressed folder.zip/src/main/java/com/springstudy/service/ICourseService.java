package com.springstudy.service;

import com.springstudy.domain.Course;

public interface ICourseService {
    Course createCourse(Course course);
    Iterable<Course> findAllCourse();
    void removeCourse(Integer courseId);

}
