package com.springstudy.service;

import com.springstudy.domain.StudentCourse;

public interface IStudentCourseService {
    StudentCourse createStudentCourse(StudentCourse studentCourse);

    Iterable<StudentCourse> findAll();

    void removeStudentCourse(Integer id);

    void removeByCourseId(Integer id);
}
