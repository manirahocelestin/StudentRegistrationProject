package com.springstudy.service;

import com.springstudy.domain.Student;

public interface IStudentServie {

    Student createStudent(Student student);

    Iterable<Student> findAllStudent();

    void removeStudent(Integer studenIdt);

}
