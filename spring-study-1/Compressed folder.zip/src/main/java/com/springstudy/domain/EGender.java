package com.springstudy.domain;

public enum EGender {
    MALE,FEMALE;
}
