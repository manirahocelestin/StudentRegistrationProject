package com.springstudy.controller;

import com.springstudy.service.ICourseService;
import com.springstudy.service.IStudentCourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CourseControllerUI {
    @Autowired
    private ICourseService courseService;

    @GetMapping("/viewCourses")
    public String viewCourses(Model model){
        model.addAttribute("list",courseService.findAllCourse());
        model.addAttribute("test","Testing");
        return "courses";
    }

    @GetMapping("/deleteCourse")
    public String delete(@RequestParam int id){

        courseService.removeCourse(id);
        // this is for redirection to the following url
        return "redirect:/viewCourses";
    }
}
